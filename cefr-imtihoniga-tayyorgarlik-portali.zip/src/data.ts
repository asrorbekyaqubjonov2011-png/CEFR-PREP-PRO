/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VocabularyWord, ScheduleItem, PracticeSet, SpeakingTopic } from "./types";

export const initialSchedule: ScheduleItem[] = [
  {
    id: "sch-1",
    date: "2026-05-25",
    title: "Diagnostic Test & Level Determination",
    description: "To'liq darajani aniqlash testi: B1, B2 yoki C1 darajasiga mosligini bilish, zaif tomonlarni yozib olish.",
    category: "Mock Exam",
    completed: true,
    priority: "high"
  },
  {
    id: "sch-2",
    date: "2026-06-01",
    title: "Vocabulary Enrichment: Collocations & Idle Talk",
    description: "CEFR imtihoni uchun eng ko'p ishlatiladigan kollokatsiyalar (set phrases) va idiomalar bilan ishlash.",
    category: "Vocabulary",
    completed: false,
    priority: "medium"
  },
  {
    id: "sch-3",
    date: "2026-06-15",
    title: "Reading Part 1 & Part 2 Matching Tactics",
    description: "Sarlavhalarni moslashtirish (Heading matching) va bo'shliqlarga jumlalarni qo'yish (Sentence insertion) texnikasi.",
    category: "Reading",
    completed: false,
    priority: "high"
  },
  {
    id: "sch-4",
    date: "2026-07-01",
    title: "Grammar Core: Gerund vs Infinitive & Inversion",
    description: "Inversion (Inverted sentences) va murakkab modal fe'llar. Lexical-grammar qismi uchun eng kerakli mavzular.",
    category: "Grammar",
    completed: false,
    priority: "high"
  },
  {
    id: "sch-5",
    date: "2026-07-15",
    title: "Writing Task 1 - Letter Writing Formats",
    description: "Formal (rasmiy) va Semi-formal xatlar uchun andozalar, foydali kirish va yakunlovchi iboralar.",
    category: "Writing",
    completed: false,
    priority: "medium"
  },
  {
    id: "sch-6",
    date: "2026-08-01",
    title: "Writing Task 2 - Discursive Essay Structure",
    description: "Opinion, Agree/Disagree, va Problem/Solution insholarini rejalashtirish va 40 daqiqada yozib tugatish mashqi.",
    category: "Writing",
    completed: false,
    priority: "high"
  },
  {
    id: "sch-7",
    date: "2026-08-10",
    title: "Speaking Mind Mapping & Cue Card Mastery",
    description: "Part 2 dagi har qanday mavzu bo'yicha 1 daqiqa ichida g'oyalar xaritasi (mind map) tuzish va 2 daqiqa to'xtovsiz gapirish.",
    category: "Speaking",
    completed: false,
    priority: "high"
  },
  {
    id: "sch-8",
    date: "2026-08-18",
    title: "Final Full Mock Exam under Time constraints",
    description: "Imtihonga 3 kun qolganda vaqtga qo'yib to'liq test topshirish va ruhan tayyorlanish.",
    category: "Mock Exam",
    completed: false,
    priority: "high"
  }
];

export const initialVocabulary: VocabularyWord[] = [
  {
    id: "vocab-1",
    word: "Alleviate",
    pos: "verb",
    translation: "Yaxshilamoq, og'riq yoki qiyinchilikni yumshatmoq",
    level: "C1",
    definition: "Make physical pain or a problem less severe.",
    example: "The government took measures to alleviate the economic crisis.",
    mastered: false
  },
  {
    id: "vocab-2",
    word: "Conspicuous",
    pos: "adjective",
    translation: "Yqqol ko'rinib turadigan, e'tibor tortadigan",
    level: "C1",
    definition: "Clearly visible or attracting attention.",
    example: "He lay in a conspicuous position on the grass.",
    mastered: false
  },
  {
    id: "vocab-3",
    word: "Detrimental",
    pos: "adjective",
    translation: "Zararli, ziyon keltiruvchi",
    level: "B2",
    definition: "Tending to cause harm or damage.",
    example: "Smoking is extremely detrimental to your physical health.",
    mastered: true
  },
  {
    id: "vocab-4",
    word: "Exaggerate",
    pos: "verb",
    translation: "Bo'rttirmoq, oshirib yubormoq",
    level: "B1",
    definition: "Represent something as being larger, better, or worse than it really is.",
    example: "Don't exaggerate the difficulty of the CEFR exam.",
    mastered: true
  },
  {
    id: "vocab-5",
    word: "Feasible",
    pos: "adjective",
    translation: "Amalga oshirsa bo'ladigan, maqbul",
    level: "B2",
    definition: "Possible to do easily or conveniently.",
    example: "It is not feasible to build a rocket in your garage.",
    mastered: false
  },
  {
    id: "vocab-6",
    word: "Hinder",
    pos: "verb",
    translation: "To'sqinlik qilmoq, xalaqit bermoq",
    level: "B2",
    definition: "Create difficulties for someone or something, resulting in delay or obstruction.",
    example: "Lack of preparation might hinder your ability to pass the test.",
    mastered: false
  },
  {
    id: "vocab-7",
    word: "Inevitable",
    pos: "adjective",
    translation: "Muqarrar, qochib bo'lmaydigan",
    level: "B2",
    definition: "Certain to happen; unavoidable.",
    example: "Some technical improvements are inevitable as time progress.",
    mastered: false
  },
  {
    id: "vocab-8",
    word: "Substantial",
    pos: "adjective",
    translation: "Salmoqli, sezilarli darajada katta",
    level: "B2",
    definition: "Of considerable importance, size, or worth.",
    example: "He made a substantial investment in English courses.",
    mastered: false
  },
  {
    id: "vocab-9",
    word: "Vague",
    pos: "adjective",
    translation: "Noaniq, xira, tushunarsiz",
    level: "B1",
    definition: "Of uncertain, indefinite, or unclear character or meaning.",
    example: "The candidate gave quite vague answers during the speaking session.",
    mastered: false
  },
  {
    id: "vocab-10",
    word: "Unprecedented",
    pos: "adjective",
    translation: "Tarixda misli ko'rilmagan",
    level: "C1",
    definition: "Never done or known before.",
    example: "The rapid development of online language portals is unprecedented.",
    mastered: false
  }
];

export const samplePracticeSets: PracticeSet[] = [
  {
    id: "prac-reading-1",
    title: "The Impact of Artificial Intelligence on Future Careers",
    category: "Reading",
    level: "B2",
    passage: `In recent years, artificial intelligence (AI) has transitions from a futuristic concept to an essential tool in everyday life. From machine-learning algorithms directing our watch feeds to sophisticated programs diagnosing medical conditions, AI is shifting how societies function.

One of the most heavily debated topics is the potential impact of automation on the job market. Historically, industrial revolutions dismantled existing professions but ultimately generated more modern jobs. For instance, the introduction of steam engines replaced manual looms but created an entirely new ecosystem of mechanics and engineers.

Experts generally agree that while AI will inevitably automate routine and repetitive physical and cognitive tasks, it is highly likely to increase demand for high-level creative and critical thinking skills. Professions that require empathy, complex negotiation, and advanced decision-making are expected to remain safe from automation. However, employees will need to continuously upscale and learn how to collaborate with AI colleagues to remain competitive.`,
    questions: [
      {
        id: "q-r1-1",
        questionText: "What is the main topic of the reading passage?",
        options: [
          "The history of the steam engine and manual weaving looms",
          "How artificial intelligence is transforming future career pathways",
          "The complete elimination of physical labor by smart algorithms",
          "Methods for medical diagnoses using automated technology"
        ],
        correctOptionIndex: 1,
        explanation: "Matnning asosiy mavzusi sun'iy intellektning kelajakdagi kasblarga va mehnat bozoriga ta'siri haqida."
      },
      {
        id: "q-r1-2",
        questionText: "According to the text, historical industrial revolutions:",
        options: [
          "Completely destroyed the economy without replacing lost professions",
          "Helped manual looms work twice as fast without steam",
          "Replaced old jobs but ultimately created new categories of employment",
          "Had no effect whatsoever on engineering and physical workers"
        ],
        correctOptionIndex: 2,
        explanation: "Ikkinchi paragrafda aytilishicha, tarixiy sanoat inqiloblari eski ishlarni siqib chiqargan bo'lsa-da, yakunda yangi ish o'rinlarini yaratgan."
      },
      {
        id: "q-r1-3",
        questionText: "Which skills are described as 'safe' from AI automation?",
        options: [
          "Routine calculations and spreadsheet data handling",
          "Manual loading and packaging of warehouse logistics",
          "Repetitive digital scheduling and customer greeting responses",
          "Empathy, complex negotiation, and advanced decision-making"
        ],
        correctOptionIndex: 3,
        explanation: "Uchinchi paragraf oxirida aytilgan: 'Professions that require empathy, complex negotiation, and advanced decision-making are expected to remain safe from automation'."
      }
    ]
  },
  {
    id: "prac-grammar-1",
    title: "Lexical & Grammatical Competence Multiple-Choice Test",
    category: "Grammar",
    level: "B2",
    questions: [
      {
        id: "q-g-1",
        questionText: "If they __________ harder for the exam, they would have scored a solid C1 certification last year.",
        options: [
          "studied",
          "had studied",
          "have studied",
          "would study"
        ],
        correctOptionIndex: 1,
        explanation: "Bu uchinchi tur shart ergash gap (Third Conditional). Kechmishdagi imkonsiz shart bo'lgani uchun 'If' qismida Past Perfect ('had studied') ishlatiladi."
      },
      {
        id: "q-g-2",
        questionText: "No sooner __________ entered the exam room than the invigilator asked everyone to switch off their phones.",
        options: [
          "had we",
          "we had",
          "did we",
          "we have"
        ],
        correctOptionIndex: 0,
        explanation: "'No sooner' inkor yuklamasi gap boshida kelsa, inversion (gap bo'laklarining o'rin almashishi) sodir bo'ladi, ya'ni yordamchi fe'l egadan oldinga o'tadi: 'No sooner had we entered...'"
      },
      {
        id: "q-g-3",
        questionText: "She has such a busy schedule that she has difficulty _________ enough free time to practice speaking.",
        options: [
          "to find",
          "finding",
          "find",
          "for finding"
        ],
        correctOptionIndex: 1,
        explanation: "'have difficulty/trouble + Gerund (-ing)' iborasi qoidasiga ko'ra, bu yerda 'finding' to'g'ri javob hisoblanadi."
      }
    ]
  }
];

export const sampleSpeakingTopics: SpeakingTopic[] = [
  {
    id: "speak-1",
    part: 1,
    title: "Your Hobbies & Leisure activities",
    prompt: "Let's talk about how you spend your free time. What are your favorite hobbies, and how often do you participate in them?",
    sampleAnswer: "To be perfectly honest, I am quite passionate about reading non-fiction and practicing my public speaking skills. Since my schedule is usually jam-packed with preparation courses, I can only dedicate about an hour daily, typically in the quiet evening hours, to unwind with an interesting book.",
    tips: [
      "Faqat qisqa 'Yes/No' deb javob bermang, har doim sabab sirtini biroz oching.",
      "Oddiy so'zlar o'rniga 'passionate about', 'jam-packed' kabi ko'proq iboralar ishlating."
    ]
  },
  {
    id: "speak-2",
    part: 2,
    title: "A memorable journey",
    prompt: "Describe an unforgettable journey you have taken in your life. You should say: where you went, whom you went with, why you went there, and explain why it remains so memorable and unique for you.",
    sampleAnswer: "I would like to describe a remarkable trip I took last autumn to the ancient city of Samarkand. I went with several close companions to experience the breathtaking architecture first-hand. It remains truly memorable because seeing the Registan Square at sunset was a genuinely emotional and eye-opening experience that made me appreciate our rich historical legacy much more deeply.",
    tips: [
      "Sizga gapirish uchun 1 daqiqa tayyorlanish vaqti beriladi, kalit so'zlarni yozib oling.",
      "Ulanish so'zlaridan (Cohesive devices) unumli foydalaning: 'Furthermore', 'What stood out most', 'With hind-sight'."
    ]
  }
];
