/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { ScheduleItem, VocabularyWord, PracticeSet } from "./types";
import { initialSchedule, initialVocabulary, samplePracticeSets } from "./data";
import SchedulePanel from "./components/SchedulePanel";
import PracticePanel from "./components/PracticePanel";
import WritingEvaluationPanel from "./components/WritingEvaluationPanel";
import VocabularyPanel from "./components/VocabularyPanel";
import TeacherChatPanel from "./components/TeacherChatPanel";
import { 
  Calendar, 
  BookOpen, 
  PenTool, 
  Award, 
  MessageSquare, 
  RefreshCw, 
  AlertCircle,
  HelpCircle,
  User,
  ExternalLink
} from "lucide-react";

export default function App() {
  // Main Panel Tab state
  const [activeTab, setActiveTab] = useState<"schedule" | "practice" | "writing" | "vocabulary" | "chat">("schedule");

  // Local storage lists states
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const [vocabulary, setVocabulary] = useState<VocabularyWord[]>([]);
  const [practiceSets, setPracticeSets] = useState<PracticeSet[]>([]);
  
  // Gemini API client status state
  const [geminiConfigured, setGeminiConfigured] = useState<boolean>(true); // default true, check from API

  // Fetch initial data or get from localStorage
  useEffect(() => {
    // 1. Get Schedule
    const localSch = localStorage.getItem("cefr_schedule");
    if (localSch) {
      try {
        setSchedule(JSON.parse(localSch));
      } catch (e) {
        setSchedule(initialSchedule);
      }
    } else {
      setSchedule(initialSchedule);
    }

    // 2. Get Vocabulary
    const localVoc = localStorage.getItem("cefr_vocabulary");
    if (localVoc) {
      try {
        setVocabulary(JSON.parse(localVoc));
      } catch (e) {
        setVocabulary(initialVocabulary);
      }
    } else {
      setVocabulary(initialVocabulary);
    }

    // 3. Get Practice Sets
    const localPrac = localStorage.getItem("cefr_practices");
    if (localPrac) {
      try {
        setPracticeSets(JSON.parse(localPrac));
      } catch (e) {
        setPracticeSets(samplePracticeSets);
      }
    } else {
      setPracticeSets(samplePracticeSets);
    }

    // 4. Ping server API config to see if Gemini is ready
    const fetchApiConfig = async () => {
      try {
        const res = await fetch("/api/config");
        if (res.ok) {
          const config = await res.json();
          setGeminiConfigured(!!config.geminiConfigured);
        }
      } catch (e) {
        console.warn("Could not fetch server configuration.", e);
        // Fallback to true or inspect
      }
    };
    fetchApiConfig();
  }, []);

  // Sync to local storage helpers
  const saveSchedule = (newSch: ScheduleItem[]) => {
    setSchedule(newSch);
    localStorage.setItem("cefr_schedule", JSON.stringify(newSch));
  };

  const saveVocabulary = (newVoc: VocabularyWord[]) => {
    setVocabulary(newVoc);
    localStorage.setItem("cefr_vocabulary", JSON.stringify(newVoc));
  };

  const savePracticeSets = (newPrac: PracticeSet[]) => {
    setPracticeSets(newPrac);
    localStorage.setItem("cefr_practices", JSON.stringify(newPrac));
  };

  // --- Handlers ---
  
  // 1. Schedule Handlers
  const handleToggleSchedule = (id: string) => {
    const updated = schedule.map(item => 
      item.id === id ? { ...item, completed: !item.completed } : item
    );
    saveSchedule(updated);
  };

  const handleAddScheduleTask = (newTask: Omit<ScheduleItem, "id">) => {
    const task: ScheduleItem = {
      ...newTask,
      id: `task-item-${Date.now()}`
    };
    saveSchedule([...schedule, task]);
  };

  const handleDeleteScheduleTask = (id: string) => {
    const updated = schedule.filter(item => item.id !== id);
    saveSchedule(updated);
  };

  // 2. Vocabulary Handlers
  const handleToggleVocabularyMastered = (id: string) => {
    const updated = vocabulary.map(wordItem => 
      wordItem.id === id ? { ...wordItem, mastered: !wordItem.mastered } : wordItem
    );
    saveVocabulary(updated);
  };

  const handleAddVocabularyWord = (newWord: Omit<VocabularyWord, "id" | "mastered">) => {
    const wordObj: VocabularyWord = {
      ...newWord,
      id: `vocab-item-${Date.now()}`,
      mastered: false
    };
    saveVocabulary([wordObj, ...vocabulary]);
  };

  // 3. Practice Handlers
  const handleAddGeneratedPracticeSet = (newSet: PracticeSet) => {
    const updated = [newSet, ...practiceSets];
    savePracticeSets(updated);
  };

  // Custom User details for header display
  const userNickname = "Asrorbek";
  const examCountdownDays = () => {
    const diff = new Date("2026-08-21T09:00:00Z").getTime() - Date.now();
    return diff > 0 ? Math.ceil(diff / (1000 * 60 * 60 * 24)) : 0;
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col selection:bg-blue-500 selection:text-white">
      
      {/* HEADER SECTION BAR */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          
          {/* Logo Brand / Human Labels */}
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 text-white p-2.5 rounded-xl flex items-center justify-center shadow-md shadow-blue-500/10">
              <Award className="w-6 h-6 stroke-2" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
                <span className="bg-blue-600 text-white px-2 py-0.5 rounded text-xs font-bold uppercase">CEFR</span>
                PrepPro 2026
              </h1>
              <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1.5 mt-0.5">
                <span>Milliy CEFR (Multi-Level) imtihonlari yo'riqnomasi</span>
                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                <span className="text-blue-600 font-bold">21-Avgust Imtihoni</span>
              </p>
            </div>
          </div>

          {/* User details and configs */}
          <div className="flex flex-wrap items-center gap-3 self-start sm:self-center">
            
            {/* User Profile Badge */}
            <div className="bg-slate-100/80 border border-slate-200/50 rounded-xl px-3.5 py-1.5 flex items-center gap-2 text-xs font-semibold text-slate-700">
              <User className="w-4 h-4 text-slate-400" />
              <div>
                <span className="block text-[9px] text-slate-400 uppercase leading-none">O'quvchi</span>
                <span className="text-slate-700 font-bold leading-none">{userNickname}</span>
              </div>
            </div>

            {/* API Status Gauge */}
            <div className={`text-xs font-bold px-3 py-1.5 rounded-xl border flex items-center gap-1.5 ${
              geminiConfigured
                ? "bg-emerald-50 border-emerald-100 text-emerald-600"
                : "bg-amber-50 border-amber-100 text-amber-600"
            }`}>
              <div className={`w-2 h-2 rounded-full ${geminiConfigured ? "bg-emerald-500" : "bg-amber-400 anim-pulse"}`}></div>
              {geminiConfigured ? "AI Bog'langan" : "AI Kalitsiz Rejim"}
            </div>
          </div>

        </div>
      </header>

      {/* SELECTION TABS CARDS - SWISS MODERN Rhythm */}
      <section className="bg-slate-900 border-b border-slate-950 text-white py-3.5 px-4 shadow-inner relative overflow-hidden">
        <div className="max-w-7xl mx-auto flex flex-wrap gap-2.5 relative z-10 justify-center md:justify-start">
          
          <button
            onClick={() => setActiveTab("schedule")}
            className={`flex items-center gap-3 px-4 py-2.5 text-xs md:text-sm font-medium rounded-lg transition-all cursor-pointer ${
              activeTab === "schedule"
                ? "bg-blue-600 text-white shadow"
                : "hover:bg-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            <Calendar className="w-4 h-4" />
            Tayyorgarlik Jadvali
          </button>

          <button
            onClick={() => setActiveTab("practice")}
            className={`flex items-center gap-3 px-4 py-2.5 text-xs md:text-sm font-medium rounded-lg transition-all cursor-pointer ${
              activeTab === "practice"
                ? "bg-blue-600 text-white shadow"
                : "hover:bg-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            <BookOpen className="w-4 h-4" />
            Testlar & Mashqlar
          </button>

          <button
            onClick={() => setActiveTab("writing")}
            className={`flex items-center gap-3 px-4 py-2.5 text-xs md:text-sm font-medium rounded-lg transition-all cursor-pointer ${
              activeTab === "writing"
                ? "bg-blue-600 text-white shadow"
                : "hover:bg-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            <PenTool className="w-4 h-4" />
            AI "Writing" Baholovchi
          </button>

          <button
            onClick={() => setActiveTab("vocabulary")}
            className={`flex items-center gap-3 px-4 py-2.5 text-xs md:text-sm font-medium rounded-lg transition-all cursor-pointer ${
              activeTab === "vocabulary"
                ? "bg-blue-600 text-white shadow"
                : "hover:bg-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            <Award className="w-4 h-4" />
            Lug'at Kartalari
          </button>

          <button
            onClick={() => setActiveTab("chat")}
            className={`flex items-center gap-3 px-4 py-2.5 text-xs md:text-sm font-medium rounded-lg transition-all cursor-pointer ${
              activeTab === "chat"
                ? "bg-blue-600 text-white shadow"
                : "hover:bg-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            Repetitor Chatbot-AI
          </button>

        </div>
      </section>

      {/* MAIN CONTAINER CONTENT VIEW */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* CONDITIONAL RENDERING OF SUB-PANELS */}
        <div className="transition-all duration-300">
          
          {activeTab === "schedule" && (
            <SchedulePanel 
              schedule={schedule}
              onToggleComplete={handleToggleSchedule}
              onAddTask={handleAddScheduleTask}
              onDeleteTask={handleDeleteScheduleTask}
            />
          )}

          {activeTab === "practice" && (
            <PracticePanel 
              practiceSets={practiceSets}
              onAddNewPracticeSet={handleAddGeneratedPracticeSet}
              geminiConfigured={geminiConfigured}
            />
          )}

          {activeTab === "writing" && (
            <WritingEvaluationPanel 
              geminiConfigured={geminiConfigured}
            />
          )}

          {activeTab === "vocabulary" && (
            <VocabularyPanel 
              vocabulary={vocabulary}
              onToggleMastered={handleToggleVocabularyMastered}
              onAddWord={handleAddVocabularyWord}
            />
          )}

          {activeTab === "chat" && (
            <TeacherChatPanel 
              geminiConfigured={geminiConfigured}
            />
          )}

        </div>

      </main>

      {/* HUMBLE FOOTER GRID */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-400 font-semibold tracking-wide">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>
            © 2026 CEFR Imtihoniga Tayyorgarlik Portal. Barcha huquqlar himoyalangan.
          </p>
          <div className="flex gap-4">
            <span className="text-slate-500 font-medium">Imtihon sanasi: 2026-yil 21-avgust</span>
            <span className="text-slate-300">|</span>
            <span className="text-slate-500 font-medium">Asrorbek Yaqubjonov uchun maxsus</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
