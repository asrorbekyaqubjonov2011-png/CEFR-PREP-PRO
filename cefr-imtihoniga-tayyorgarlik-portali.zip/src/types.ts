/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface VocabularyWord {
  id: string;
  word: string;
  pos: string; // Part of speech (noun, verb, adj, etc.)
  translation: string; // Uzbek translation
  level: "B1" | "B2" | "C1";
  definition: string;
  example: string;
  mastered: boolean;
}

export interface ScheduleItem {
  id: string;
  date: string; // YYYY-MM-DD
  title: string;
  description: string;
  category: "Reading" | "Listening" | "Writing" | "Speaking" | "Grammar" | "Vocabulary" | "Mock Exam";
  completed: boolean;
  priority: "high" | "medium" | "low";
}

export interface Question {
  id: string;
  questionText: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
}

export interface PracticeSet {
  id: string;
  title: string;
  category: "Reading" | "Grammar" | "Listening";
  level: "B1" | "B2" | "C1";
  passage?: string; // HTML or Markdown for Reading passages
  questions: Question[];
}

export interface WritingSubmission {
  taskNumber: 1 | 2;
  prompt: string;
  studentAnswer: string;
}

export interface FeedbackDetail {
  score: string; // E.g. "B2", "C1 (7.5)", etc.
  coherenceText: string;
  lexicalText: string;
  grammaticalText: string;
  taskAchievementText: string;
  improvedVersion: string;
}

export interface SpeakingTopic {
  id: string;
  part: 1 | 2 | 3;
  title: string;
  prompt: string;
  sampleAnswer?: string;
  tips?: string[];
}
