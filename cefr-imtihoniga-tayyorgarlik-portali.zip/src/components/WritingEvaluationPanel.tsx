/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { FeedbackDetail } from "../types";
import { PenTool, CheckCircle, RefreshCw, Award, BookOpen, AlertCircle, HelpCircle } from "lucide-react";

interface WritingEvaluationPanelProps {
  geminiConfigured: boolean;
}

const presetPromptsList = [
  {
    id: "task-1-p1",
    taskNumber: 1 as const,
    title: "Task 1: Email to a friend about a modern device",
    promptText: "Write an email to a friend explaining a technology device you bought recently. Describe what it is, why you bought it, and how it makes your life easier. Write at least 150 words."
  },
  {
    id: "task-2-p1",
    taskNumber: 2 as const,
    title: "Task 2: Education and Future career perspectives",
    promptText: "Some people believe that university education should focus purely on practical skills needed for employment, while others believe its primary role is to provide a broad academic knowledge base. Discuss both views and give your opinion. Write at least 250 words."
  }
];

export default function WritingEvaluationPanel({
  geminiConfigured
}: WritingEvaluationPanelProps) {
  const [activePresetIndex, setActivePresetIndex] = useState<number>(0);
  const [studentText, setStudentText] = useState<string>("");
  const [customPromptEnabled, setCustomPromptEnabled] = useState<boolean>(false);
  const [customPromptText, setCustomPromptText] = useState<string>("");

  const activePreset = presetPromptsList[activePresetIndex];
  const finalPrompt = customPromptEnabled ? customPromptText : activePreset.promptText;
  const activeTaskNumber = customPromptEnabled ? 2 : activePreset.taskNumber;

  // Evaluation States
  const [evaluation, setEvaluation] = useState<FeedbackDetail | null>(null);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [evalError, setEvalError] = useState<string | null>(null);

  // Live counters
  const wordCount = studentText.trim() === "" ? 0 : studentText.trim().split(/\s+/).length;
  const minRequiredWords = activeTaskNumber === 1 ? 150 : 250;

  const handleEvaluate = async () => {
    if (!studentText.trim() || studentText.length < 20) {
      alert("Iltimos, avval inshongizni yozing (kamida 20 ta belgi).");
      return;
    }

    setIsEvaluating(true);
    setEvalError(null);
    setEvaluation(null);

    try {
      const response = await fetch("/api/evaluate-writing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          taskNumber: activeTaskNumber,
          prompt: finalPrompt,
          studentAnswer: studentText
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Inshoni baholashda xatolik yuz berdi");
      }

      const evalData = await response.json();
      setEvaluation(evalData);
    } catch (err: any) {
      setEvalError(err.message || "Ulanish yuz bermadi");
    } finally {
      setIsEvaluating(false);
    }
  };

  const handleReset = () => {
    setStudentText("");
    setEvaluation(null);
    setEvalError(null);
  };

  return (
    <div id="writing-evaluation-panel" className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-800 flex items-center gap-2">
            <PenTool className="w-5 h-5 text-blue-600" />
            AI "Writing" Insho Pro-Tekshiruvchi
          </h2>
          <p className="text-xs text-slate-500">
            CEFR dushanba testiga tayyorlanishda insholaringizni yozing va DTM / CEFR baholash mezonlari asosida tahlil oling.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* INPUT FORM AND WRITER */}
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            {/* PROMPT SELECTOR */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-slate-400 uppercase">Mavzuni tanlang:</label>
                <button
                  type="button"
                  onClick={() => {
                    setCustomPromptEnabled(!customPromptEnabled);
                    setEvaluation(null);
                  }}
                  className="text-xs font-bold text-blue-600 hover:text-blue-800 transition-colors"
                >
                  {customPromptEnabled ? "Tayyor mavzulardan foydalanish" : "O'z mavzumni yozish"}
                </button>
              </div>

              {!customPromptEnabled ? (
                <div className="flex gap-2 mb-3">
                  {presetPromptsList.map((preset, pIdx) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setActivePresetIndex(pIdx);
                        setEvaluation(null);
                      }}
                      className={`flex-1 text-left p-3 rounded-lg border text-xs font-medium transition-all ${
                        activePresetIndex === pIdx && !customPromptEnabled
                          ? "ring-2 ring-blue-500 border-blue-500 bg-blue-50/10"
                          : "bg-slate-50 border-slate-200 hover:bg-slate-100"
                      }`}
                    >
                      <h5 className="font-bold text-slate-700 mb-1">{preset.title}</h5>
                      <p className="text-[10px] text-slate-400 line-clamp-1">{preset.promptText}</p>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="mb-3">
                  <input
                    type="text"
                    value={customPromptText}
                    onChange={(e) => setCustomPromptText(e.target.value)}
                    placeholder="Insho topshirig'i (Prompt) matnini bu yerga yozing..."
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-700"
                  />
                </div>
              )}

              {/* ACTIVE PROMPT DISPLAY */}
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 text-xs font-medium text-slate-600">
                <span className="font-bold text-slate-800 uppercase text-[10px] block mb-1 text-blue-600">
                  Imtihon topshirig'i:
                </span>
                <p className="leading-relaxed whitespace-pre-line">{finalPrompt || "Iltimos mavzu matnini kiriting."}</p>
              </div>
            </div>

            {/* TEXTAREA WRITING CANVAs */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold text-slate-400 uppercase">Sizning inshongiz:</label>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
                  wordCount >= minRequiredWords ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"
                }`}>
                  {wordCount} / {minRequiredWords} so'z
                </span>
              </div>

              <textarea
                value={studentText}
                onChange={(e) => setStudentText(e.target.value)}
                rows={12}
                disabled={isEvaluating}
                placeholder="Ingliz tilida yozilgan xatingiz yoki inshongizni bu yerga kiritib tahlil qildiring..."
                className="w-full text-sm font-sans p-4 border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-blue-400 text-slate-700 leading-relaxed shadow-sm disabled:opacity-70"
              />
            </div>

            {/* ACTIONS */}
            <div className="flex justify-between items-center pt-2">
              <button
                type="button"
                onClick={handleReset}
                className="text-xs font-bold text-slate-400 hover:text-slate-600 py-2.5 transition-colors"
              >
                Matnni tozalash
              </button>

              <button
                type="button"
                onClick={handleEvaluate}
                disabled={isEvaluating || studentText.length < 10}
                className="bg-blue-600 border border-blue-500 hover:bg-blue-700 text-white font-bold py-2.5 px-6 rounded-xl text-xs transition-all shadow-md flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isEvaluating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    Sun'iy Intellekt tahlil qilmoqda...
                  </>
                ) : (
                  <>
                    <PenTool className="w-4 h-4 text-blue-200" />
                    Inshoni baholash
                  </>
                )}
              </button>
            </div>

            {evalError && (
              <div className="bg-rose-50 border border-rose-100 rounded-xl p-4 text-xs text-rose-600 font-medium">
                {evalError}
              </div>
            )}
          </div>
        </div>

        {/* FEEDBACK & EVALUATION COLUMN */}
        <div className="lg:col-span-2 space-y-6">
          {!evaluation && !isEvaluating && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-8 text-center text-slate-500 h-full flex flex-col justify-center items-center shadow-inner">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border border-slate-100 text-slate-400 mb-3 shadow-md">
                <PenTool className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-800 mb-1">Insho tekshiruvi kutilmoqda</p>
              <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                Chap tomondagi maydonga inshoni kiriting va imtihondagi xatolaringizni tahlil qilish uchun "Inshoni baholash" tugmasini bosing.
              </p>
              {!geminiConfigured && (
                <div className="mt-4 bg-orange-50 border border-orange-100 text-orange-600 text-[10px] font-bold p-3 rounded-lg leading-relaxed">
                  * Gemini API bog'lanmagan. Iltimos o'ng tarafdagi Secrets bo'limini sozlang.
                </div>
              )}
            </div>
          )}

          {isEvaluating && (
            <div className="bg-white border border-slate-200 rounded-xl p-8 text-center h-full flex flex-col justify-center items-center shadow-sm space-y-4">
              <div className="relative">
                <div className="w-16 h-16 border-4 border-blue-100 border-t-blue-600 rounded-full animate-spin"></div>
                <PenTool className="w-6 h-6 text-blue-600 absolute top-5 left-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">Insho baholanmoqda...</h4>
                <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                  Sun'iy intellekt xatlarning leksikasi, grammatik xatoliklari va bog'liqlik mezonlarini batafsil tahlil qilmoqda. Bu taxminan 5-15 soniya vaqt oladi.
                </p>
              </div>
            </div>
          )}

          {/* REAL EVALUATION REPORT LIST */}
          {evaluation && !isEvaluating && (
            <div className="space-y-4">
              {/* PRIMARY BAND SCORE */}
              <div className="bg-gradient-to-br from-slate-900 via-slate-850 to-blue-950 text-white rounded-xl p-5 shadow-lg border border-slate-700 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl"></div>
                <div className="relative z-10 flex items-center gap-4">
                  <div className="bg-blue-500/30 border border-blue-500/20 w-16 h-16 rounded-full flex flex-col items-center justify-center flex-shrink-0">
                    <span className="block text-[10px] text-blue-200 uppercase font-bold tracking-widest leading-none">Olingan</span>
                    <span id="writing-band-score" className="block text-xl font-black">{evaluation.score}</span>
                  </div>
                  <div className="space-y-0.5">
                    <span className="bg-blue-300/20 text-blue-300 font-semibold text-[10px] px-2 py-0.5 rounded uppercase tracking-widest">Baholash natijasi</span>
                    <h4 className="font-extrabold text-sm md:text-base leading-tight">Idrok etilgan daraja</h4>
                    <p className="text-[10px] text-slate-300 font-medium leading-relaxed">Uzbekistan DTM CEFR imtihoni ssenariylari asosida.</p>
                  </div>
                </div>
              </div>

              {/* SECTION EVALS */}
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-3.5">
                <h5 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider text-blue-600">Batafsil tahlillar:</h5>

                <div className="space-y-3 font-sans text-xs">
                  <div>
                    <span className="font-bold text-slate-700 flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5 text-blue-600" />
                      Bog'liqlik (Coherence & Cohesion):
                    </span>
                    <p className="text-slate-500 mt-1 pl-4 leading-relaxed font-semibold">{evaluation.coherenceText}</p>
                  </div>

                  <div>
                    <span className="font-bold text-slate-700 flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5 text-blue-600" />
                      Lug'at boyligi (Lexical Resource):
                    </span>
                    <p className="text-slate-500 mt-1 pl-4 leading-relaxed font-semibold">{evaluation.lexicalText}</p>
                  </div>

                  <div>
                    <span className="font-bold text-slate-700 flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5 text-blue-600" />
                      Gramatika aniqligi (Grammatical Range):
                    </span>
                    <p className="text-slate-500 mt-1 pl-4 leading-relaxed font-semibold">{evaluation.grammaticalText}</p>
                  </div>

                  <div>
                    <span className="font-bold text-slate-700 flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5 text-blue-600" />
                      Vazifani bajarganlik (Task Achievement):
                    </span>
                    <p className="text-slate-500 mt-1 pl-4 leading-relaxed font-semibold">{evaluation.taskAchievementText}</p>
                  </div>
                </div>
              </div>

              {/* IMPROVED VERSION EXCEL PREVIEW */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm space-y-2">
                <h5 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider text-blue-600 flex items-center gap-1">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                  Yaxshilangan insho namunasi (Improved Model):
                </h5>
                <p className="text-[10px] text-slate-400 italic">Xatolardan xoli bo'lgan, B2/C1 darajasidagi tavsiya etiladigan namuna:</p>
                <div className="bg-white border border-slate-100 p-3.5 rounded-lg text-xs font-sans text-slate-600 font-medium leading-relaxed whitespace-pre-line select-text">
                  {evaluation.improvedVersion}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
