/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { VocabularyWord } from "../types";
import { RefreshCw, BookOpen, CheckCircle, Search, Plus, Award } from "lucide-react";

interface VocabularyPanelProps {
  vocabulary: VocabularyWord[];
  onToggleMastered: (id: string) => void;
  onAddWord: (word: Omit<VocabularyWord, "id" | "mastered">) => void;
}

export default function VocabularyPanel({
  vocabulary,
  onToggleMastered,
  onAddWord
}: VocabularyPanelProps) {
  const [levelFilter, setLevelFilter] = useState<string>("All");
  const [masterFilter, setMasterFilter] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");

  // Add word state
  const [isAdding, setIsAdding] = useState(false);
  const [word, setWord] = useState("");
  const [pos, setPos] = useState("noun");
  const [translation, setTranslation] = useState("");
  const [level, setLevel] = useState<"B1" | "B2" | "C1">("B2");
  const [definition, setDefinition] = useState("");
  const [example, setExample] = useState("");

  // Card flip helper
  const [flippedWordId, setFlippedWordId] = useState<string | null>(null);

  const handleFlip = (id: string) => {
    setFlippedWordId(flippedWordId === id ? null : id);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!word.trim() || !translation.trim()) return;

    onAddWord({
      word,
      pos,
      translation,
      level,
      definition,
      example
    });

    setWord("");
    setTranslation("");
    setDefinition("");
    setExample("");
    setIsAdding(false);
  };

  const filteredWords = vocabulary.filter(w => {
    if (levelFilter !== "All" && w.level !== levelFilter) return false;
    if (masterFilter === "Mastered" && !w.mastered) return false;
    if (masterFilter === "Learning" && w.mastered) return false;
    if (searchQuery.trim() !== "") {
      const q = searchQuery.toLowerCase();
      const matchWord = w.word.toLowerCase().includes(q);
      const matchTrans = w.translation.toLowerCase().includes(q);
      return matchWord || matchTrans;
    }
    return true;
  });

  const masteredCount = vocabulary.filter(w => w.mastered).length;
  const progressPercent = vocabulary.length > 0 ? Math.round((masteredCount / vocabulary.length) * 100) : 0;

  return (
    <div id="vocabulary-panel" className="space-y-6">
      {/* VOCAB STATS BOX */}
      <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col md:flex-row gap-6 md:items-center justify-between">
        <div className="space-y-1">
          <h3 className="font-bold text-slate-800 flex items-center gap-2">
            <Award className="w-5 h-5 text-blue-600" />
            Lug'at Boyligi Rivoji (CEFR Levels)
          </h3>
          <p className="text-xs text-slate-400">Yod olingan so'zlar imtihonda yuqori ball (C1) olishingiz imkonini kafolatlaydi.</p>
        </div>

        <div className="flex-1 max-w-sm w-full">
          <div className="flex justify-between items-center mb-1 text-xs font-semibold">
            <span className="text-slate-500">{masteredCount} / {vocabulary.length} o'zlashtirildi</span>
            <span className="text-blue-600">{progressPercent}%</span>
          </div>
          <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-emerald-500 to-blue-600 transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* FILTERS & DOCK BAR */}
        <div className="space-y-6 lg:col-span-1">
          {/* ADD WORD UTILITY CARD */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm">
            <div className="flex justify-between items-center mb-3">
              <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider text-blue-600 flex items-center gap-1.5">
                <BookOpen className="w-4 h-4" /> Yangi so'z qo'shish
              </h4>
              <button
                onClick={() => setIsAdding(!isAdding)}
                className="text-blue-600 hover:text-blue-800 text-xs font-bold transition-all"
              >
                {isAdding ? "Yopish" : "Ochish"}
              </button>
            </div>

            {isAdding ? (
              <form onSubmit={handleAddSubmit} className="space-y-3.5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">So'z (Inglizcha)</label>
                  <input
                    type="text"
                    required
                    value={word}
                    onChange={(e) => setWord(e.target.value)}
                    placeholder="Masalan: Reluctance"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 text-slate-700"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Turi (POS)</label>
                    <select
                      value={pos}
                      onChange={(e) => setPos(e.target.value)}
                      className="w-full text-xs px-2 py-2 border border-slate-200 rounded-lg bg-white"
                    >
                      <option value="noun">Noun</option>
                      <option value="verb">Verb</option>
                      <option value="adjective">Adjective</option>
                      <option value="adverb">Adverb</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">CEFR Darajasi</label>
                    <select
                      value={level}
                      onChange={(e) => setLevel(e.target.value as "B1" | "B2" | "C1")}
                      className="w-full text-xs px-2 py-2 border border-slate-200 rounded-lg bg-white"
                    >
                      <option value="B1">B1</option>
                      <option value="B2">B2</option>
                      <option value="C1">C1</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Tarjimasi (O'zbekcha)</label>
                  <input
                    type="text"
                    required
                    value={translation}
                    onChange={(e) => setTranslation(e.target.value)}
                    placeholder="Masalan: Istamaslik, xohish yo'qligi"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 text-slate-700"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Inglizcha Ta'rifi</label>
                  <input
                    type="text"
                    value={definition}
                    onChange={(e) => setDefinition(e.target.value)}
                    placeholder="An unwillingness to do something..."
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 text-slate-700"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Gapda Ishlatilishi</label>
                  <input
                    type="text"
                    value={example}
                    onChange={(e) => setExample(e.target.value)}
                    placeholder="She showed reluctance to attend the seminar."
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 text-slate-700"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-colors shadow-sm"
                >
                  Lug'atga qo'shish
                </button>
              </form>
            ) : (
              <p className="text-xs text-slate-400 leading-relaxed font-medium">
                Siz yangi o'rganayotgan so'zlaringizni va tarjimalarini qo'shishingiz va o'rganish kartasi yordamida takrorlab borishingiz mumkin.
              </p>
            )}
          </div>

          {/* SEARCH & FILTER LISTS */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <h4 className="font-bold text-slate-800 text-sm">Filtr va qidiruv</h4>

            {/* QUERY INPUT */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute top-3 left-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="So'z yoki tarjima qidirish..."
                className="w-full text-xs pl-8 pr-3 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 text-slate-700 font-medium"
              />
            </div>

            {/* LEVEL SELECTOR */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-400 uppercase">CEFR Daraja</label>
              <div className="flex gap-1">
                {["All", "B1", "B2", "C1"].map(lvl => (
                  <button
                    key={lvl}
                    onClick={() => setLevelFilter(lvl)}
                    className={`flex-1 text-center py-1 text-xs font-semibold rounded ${
                      levelFilter === lvl
                        ? "bg-slate-900 text-white"
                        : "bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100"
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>

            {/* MASTER STATUS */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-400 uppercase">O'rganish holati</label>
              <div className="flex gap-1.5">
                {["All", "Learning", "Mastered"].map(mst => (
                  <button
                    key={mst}
                    onClick={() => setMasterFilter(mst)}
                    className={`flex-1 text-center py-1 text-[11px] font-semibold rounded ${
                      masterFilter === mst
                        ? "bg-blue-600 text-white"
                        : "bg-slate-50 text-slate-500 border border-slate-200 hover:bg-slate-100"
                    }`}
                  >
                    {mst === "All" ? "Barchasi" : mst === "Learning" ? "Yodlanayotgan" : "Yodlangan"}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* STUDY CODES AND MEMORY FLIP CARDS GRID (3 Columns on Big Screens) */}
        <div className="lg:col-span-3 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-slate-800 text-base">CEFR Kartalari ({filteredWords.length})</h3>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">Karta ustiga bosib tarjimasini ko'ring</span>
          </div>

          {filteredWords.length === 0 ? (
            <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-sm">
              <div className="w-12 h-12 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-3">
                <BookOpen className="w-6 h-6" />
              </div>
              <p className="text-slate-500 font-semibold mb-1">Qidiruv bo'yicha so'z topilmadi</p>
              <p className="text-xs text-slate-400">Filtrni qayta sozlang yoki yangi so'z qo'shing.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredWords.map(wordItem => {
                const isFlipped = flippedWordId === wordItem.id;
                const isC1 = wordItem.level === "C1";
                const isB2 = wordItem.level === "B2";

                return (
                  <div
                    key={wordItem.id}
                    id={`karta-${wordItem.id}`}
                    onClick={() => handleFlip(wordItem.id)}
                    className={`relative min-h-[170px] cursor-pointer rounded-xl border p-5 transition-all shadow-sm flex flex-col justify-between select-none ${
                      isFlipped
                        ? "bg-slate-900 border-slate-800 text-white"
                        : "bg-white border-slate-200/80 hover:border-blue-300"
                    }`}
                  >
                    {/* TOP BADGE ACTION */}
                    <div className="flex items-center justify-between pb-3">
                      <div className="flex gap-2">
                        <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                          isC1 
                            ? "bg-rose-100 text-rose-600 font-black border border-rose-200" 
                            : isB2 
                            ? "bg-amber-100 text-amber-600 font-bold border border-amber-200" 
                            : "bg-blue-100 text-blue-600 font-bold border border-blue-200"
                        }`}>
                          {wordItem.level}
                        </span>
                        <span className="text-[10px] font-bold text-slate-400 italic">
                          {wordItem.pos}
                        </span>
                      </div>

                      {/* MASTER TRACKER BUTTON */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation(); // Stop flipping when toggling mastered
                          onToggleMastered(wordItem.id);
                        }}
                        className={`text-xs font-semibold px-2 py-0.5 rounded flex items-center gap-1.5 transition-colors ${
                          wordItem.mastered
                            ? "bg-emerald-50 text-emerald-600 border border-emerald-200"
                            : "bg-slate-100 text-slate-400 hover:bg-slate-200"
                        }`}
                        title={wordItem.mastered ? "Yodlangan deb belgilangan" : "Yodlanmoqda"}
                      >
                        <CheckCircle className={`w-3 h-3 ${wordItem.mastered ? "text-emerald-600" : "text-slate-400"}`} />
                        {wordItem.mastered ? "Yodlangan" : "O'rganilmoqda"}
                      </button>
                    </div>

                    {/* DYNAMIC CARD CONTENT */}
                    <div className="flex-1 py-1">
                      {!isFlipped ? (
                        <div className="space-y-1 mt-1">
                          <h4 className="text-xl font-extrabold tracking-tight text-slate-800">
                            {wordItem.word}
                          </h4>
                          <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                            {wordItem.definition || "No definition specified. Click card to review translation."}
                          </p>
                        </div>
                      ) : (
                        <div className="space-y-1.5 text-slate-100">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">O'zbekcha tarjimasi:</span>
                          <h4 className="text-lg font-bold text-blue-300 leading-tight">
                            {wordItem.translation}
                          </h4>
                          {wordItem.example && (
                            <p className="text-xs text-slate-400 leading-relaxed italic block mt-1 border-t border-slate-800 pt-1.5">
                              Ex: "{wordItem.example}"
                            </p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* FLIP INSTRUCTION HINT ALIGNMENT */}
                    <div className="text-[9px] text-right text-slate-400 uppercase font-extrabold tracking-widest pt-2 flex items-center gap-1 ml-auto">
                      <RefreshCw className="w-2.5 h-2.5" />
                      {!isFlipped ? "tarjimasi" : "asl so'z"}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
