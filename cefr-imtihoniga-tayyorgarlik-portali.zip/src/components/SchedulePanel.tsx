/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { ScheduleItem } from "../types";
import { Calendar, CheckCircle, Clock, AlertCircle, Trash2, Plus, RefreshCw } from "lucide-react";

interface SchedulePanelProps {
  schedule: ScheduleItem[];
  onToggleComplete: (id: string) => void;
  onAddTask: (task: Omit<ScheduleItem, "id">) => void;
  onDeleteTask: (id: string) => void;
}

export default function SchedulePanel({
  schedule,
  onToggleComplete,
  onAddTask,
  onDeleteTask
}: SchedulePanelProps) {
  // Calendar countdown calculation (to August 21, 2026)
  const examDate = new Date("2026-08-21T09:00:00Z");
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const calculateTime = () => {
      const difference = examDate.getTime() - Date.now();
      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }
      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((difference / 1000 / 60) % 60);
      const seconds = Math.floor((difference / 1000) % 60);
      setTimeLeft({ days, hours, minutes, seconds });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Form states for new task
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newCategory, setNewCategory] = useState<ScheduleItem["category"]>("Grammar");
  const [newPriority, setNewPriority] = useState<ScheduleItem["priority"]>("medium");
  const [newDate, setNewDate] = useState("2026-08-01");

  // Filters
  const [categoryFilter, setCategoryFilter] = useState<string>("All");
  const [statusFilter, setStatusFilter] = useState<string>("All");

  const completedCount = schedule.filter(s => s.completed).length;
  const progressPercent = schedule.length > 0 ? Math.round((completedCount / schedule.length) * 100) : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onAddTask({
      title: newTitle,
      description: newDesc,
      category: newCategory,
      priority: newPriority,
      date: newDate,
      completed: false
    });
    setNewTitle("");
    setNewDesc("");
    setIsAdding(false);
  };

  const filteredSchedule = schedule.filter(item => {
    if (categoryFilter !== "All" && item.category !== categoryFilter) return false;
    if (statusFilter === "Completed" && !item.completed) return false;
    if (statusFilter === "Pending" && item.completed) return false;
    return true;
  });

  return (
    <div id="schedule-panel" className="space-y-6">
      {/* EXAM COUNTDOWN HERO BLOCK */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white rounded-2xl p-6 md:p-8 shadow-xl relative overflow-hidden border border-slate-700">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-8 -left-8 w-40 h-40 bg-purple-500/10 rounded-full blur-2xl"></div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="space-y-2">
            <span className="bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wider">
              CEFR Imtihoni Countdown
            </span>
            <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              21-Avgust Imtihonigacha Qolgan Vaqt
            </h2>
            <p className="text-slate-300 max-w-md text-sm md:text-base">
              Har bir soniyadan unumli foydalaning. Quyida siz uchun maxsus rejalashtirilgan bosqichli vazifalarni bajaring!
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-slate-800/80 backdrop-blur border border-slate-700 rounded-xl p-3 text-center min-w-[70px]">
              <span className="block text-2xl md:text-3xl font-bold font-mono text-blue-400">{timeLeft.days}</span>
              <span className="text-[10px] text-slate-400 uppercase tracking-widest">Kun</span>
            </div>
            <div className="bg-slate-800/80 backdrop-blur border border-slate-700 rounded-xl p-3 text-center min-w-[70px]">
              <span className="block text-2xl md:text-3xl font-bold font-mono text-blue-400">{timeLeft.hours}</span>
              <span className="text-[10px] text-slate-400 uppercase tracking-widest">Soat</span>
            </div>
            <div className="bg-slate-800/80 backdrop-blur border border-slate-700 rounded-xl p-3 text-center min-w-[70px]">
              <span className="block text-2xl md:text-3xl font-bold font-mono text-blue-400">{timeLeft.minutes}</span>
              <span className="text-[10px] text-slate-400 uppercase tracking-widest">Daqiqa</span>
            </div>
            <div className="bg-slate-800/80 backdrop-blur border border-slate-700 rounded-xl p-3 text-center min-w-[70px]">
              <span className="block text-2xl md:text-3xl font-bold font-mono text-emerald-400">{timeLeft.seconds}</span>
              <span className="text-[10px] text-slate-400 uppercase tracking-widest">Soniya</span>
            </div>
          </div>
        </div>
      </div>

      {/* PROGRESS SCOREBOARD */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center gap-6 justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-slate-600">
            <CheckCircle className="w-5 h-5 text-blue-600" />
            <span className="font-semibold text-sm">Vazifalar Bajarilishi Progressi</span>
          </div>
          <p className="text-xs text-slate-400">Biz rejalashtirgan dars mashg'ulotlarining o'zlashtirilish darajasi.</p>
        </div>

        <div className="flex-1 max-w-md w-full">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs font-semibold text-slate-500">{completedCount} / {schedule.length} bajarildi</span>
            <span className="text-xs font-bold text-blue-600">{progressPercent}%</span>
          </div>
          <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* SCHEDULE LIST SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* FILTERS & TASK ADDER */}
        <div className="lg:col-span-1 space-y-6">
          {/* CREATE TASK ACTION */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-slate-800 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-600" />
                Vazifa qo'shish
              </h3>
              {!isAdding ? (
                <button
                  onClick={() => setIsAdding(true)}
                  className="bg-blue-50 hover:bg-blue-100 text-blue-600 text-xs px-2.5 py-1.5 rounded-lg font-semibold flex items-center gap-1 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" /> Yangi
                </button>
              ) : (
                <button
                  onClick={() => setIsAdding(false)}
                  className="text-slate-400 hover:text-slate-600 text-xs font-medium"
                >
                  Yopish
                </button>
              )}
            </div>

            {isAdding && (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Mavzu / Nomi</label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="Masalan: Essay Writing Practice"
                    className="w-full text-sm px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Tavsif (Nima qilasiz)</label>
                  <textarea
                    rows={2}
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    placeholder="Masalan: Writing Task 2 bo'yicha onlayn maslahat..."
                    className="w-full text-sm px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Kategoriya</label>
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value as ScheduleItem["category"])}
                      className="w-full text-xs px-2.5 py-2 border border-slate-200 rounded-lg bg-white"
                    >
                      <option value="Grammar">Grammar</option>
                      <option value="Vocabulary">Vocabulary</option>
                      <option value="Reading">Reading</option>
                      <option value="Listening">Listening</option>
                      <option value="Writing">Writing</option>
                      <option value="Speaking">Speaking</option>
                      <option value="Mock Exam">Mock Exam</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Muhimlik</label>
                    <select
                      value={newPriority}
                      onChange={(e) => setNewPriority(e.target.value as ScheduleItem["priority"])}
                      className="w-full text-xs px-2.5 py-2 border border-slate-200 rounded-lg bg-white"
                    >
                      <option value="low">Past</option>
                      <option value="medium">O'rta</option>
                      <option value="high">Yuqori</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Muddat (Sana)</label>
                  <input
                    type="date"
                    required
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full text-sm px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-colors shadow-sm"
                >
                  Rejaga qo'shish
                </button>
              </form>
            )}

            {!isAdding && (
              <p className="text-xs text-slate-400 italic">
                Siz ham o'z shaxsiy tayyorgarlik rejangizga topshiriq va maqsadlarni qo'shishingiz va o'zlashtirganingiz sari belgilab borishingiz mumkin.
              </p>
            )}
          </div>

          {/* QUICK FILTER PANEL */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
            <h3 className="font-bold text-slate-800 text-sm">Filtrlash</h3>
            <div className="space-y-2">
              <label className="block text-xs font-medium text-slate-400">Kategoriya bo'yicha</label>
              <div className="flex flex-wrap gap-1.5">
                {["All", "Grammar", "Vocabulary", "Reading", "Listening", "Writing", "Speaking", "Mock Exam"].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCategoryFilter(cat)}
                    className={`text-[11px] px-2.5 py-1 rounded-full font-medium transition-colors ${
                      categoryFilter === cat
                        ? "bg-blue-600 text-white"
                        : "bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-medium text-slate-400">Holat bo'yicha</label>
              <div className="flex gap-2">
                {["All", "Pending", "Completed"].map((status) => (
                  <button
                    key={status}
                    onClick={() => setStatusFilter(status)}
                    className={`flex-1 text-center py-1.5 text-xs rounded-lg font-semibold transition-colors border ${
                      statusFilter === status
                        ? "bg-slate-900 border-slate-900 text-white"
                        : "bg-white hover:bg-slate-50 text-slate-600 border-slate-200"
                    }`}
                  >
                    {status === "All" ? "Hammasi" : status === "Pending" ? "Kutilayotgan" : "Bajarilgan"}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* STUDY LIST GRID */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-slate-800">
              Dars mashg'ulotlari jadvali ({filteredSchedule.length})
            </h3>
            <span className="text-xs text-slate-400 font-medium">Sana boyicha tartiblangan</span>
          </div>

          {filteredSchedule.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl p-12 text-center shadow-sm">
              <div className="w-12 h-12 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-3">
                <Calendar className="w-6 h-6" />
              </div>
              <p className="text-slate-500 font-semibold mb-1">Hech qanday dars topilmadi</p>
              <p className="text-xs text-slate-400">Tanlovingizga mos tushadigan reja elementini topa olmadik.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredSchedule.map((item) => {
                const isHigh = item.priority === "high";
                const isMed = item.priority === "medium";

                return (
                  <div
                    key={item.id}
                    id={`task-${item.id}`}
                    className={`bg-white rounded-xl p-4 border transition-all shadow-sm flex flex-col sm:flex-row sm:items-start gap-4 ${
                      item.completed 
                        ? "border-slate-100 opacity-75 grayscale-20" 
                        : "border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    {/* CHECKBOX */}
                    <button
                      onClick={() => onToggleComplete(item.id)}
                      className="mt-0.5 flex-shrink-0"
                    >
                      <div className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                        item.completed
                          ? "bg-blue-600 border-blue-600 text-white"
                          : "border-slate-300 hover:border-blue-400"
                      }`}>
                        {item.completed && (
                          <svg className="w-3.5 h-3.5 stroke-2 stroke-current" fill="none" viewBox="0 0 24 24">
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                        )}
                      </div>
                    </button>

                    {/* CONTENT */}
                    <div className="flex-1 space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2">
                        {/* CATEGORY TAG */}
                        <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                          {item.category}
                        </span>

                        {/* PRIORITY TAG */}
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase flex items-center gap-1 ${
                          isHigh 
                            ? "bg-rose-50 text-rose-600 border border-rose-100" 
                            : isMed 
                            ? "bg-amber-50 text-amber-600 border border-amber-100" 
                            : "bg-slate-50 text-slate-400 border border-slate-100"
                        }`}>
                          <AlertCircle className="w-2.5 h-2.5" />
                          {item.priority === "high" ? "yuqori" : item.priority === "medium" ? "o'rta" : "past"}
                        </span>

                        {/* DATE BADGE */}
                        <span className="text-xs font-mono text-slate-400 ml-auto flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-slate-300" />
                          {item.date}
                        </span>
                      </div>

                      <h4 className={`font-bold transition-all text-sm md:text-base ${
                        item.completed ? "line-through text-slate-400" : "text-slate-800"
                      }`}>
                        {item.title}
                      </h4>

                      <p className="text-xs text-slate-500 md:text-sm font-medium leading-relaxed">
                        {item.description}
                      </p>
                    </div>

                    {/* DELETE OPTION */}
                    <button
                      onClick={() => onDeleteTask(item.id)}
                      className="text-slate-300 hover:text-red-500 p-1.5 rounded-lg hover:bg-rose-50 transition-colors ml-auto sm:self-center"
                      title="O'chirish"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
