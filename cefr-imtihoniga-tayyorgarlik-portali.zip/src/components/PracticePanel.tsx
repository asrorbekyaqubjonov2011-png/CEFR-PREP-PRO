/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { PracticeSet, Question } from "../types";
import { BookOpen, Award, CheckCircle, RefreshCw, Sparkles, HelpCircle, ArrowRight } from "lucide-react";

interface PracticePanelProps {
  practiceSets: PracticeSet[];
  onAddNewPracticeSet: (newSet: PracticeSet) => void;
  geminiConfigured: boolean;
}

export default function PracticePanel({
  practiceSets,
  onAddNewPracticeSet,
  geminiConfigured
}: PracticePanelProps) {
  // Selected Practice Set and Quiz States
  const [activeSetId, setActiveSetId] = useState<string>(practiceSets[0]?.id || "");
  const [userAnswers, setUserAnswers] = useState<{ [qId: string]: number }>({});
  const [submitted, setSubmitted] = useState<boolean>(false);

  // AI Generation States
  const [generationLevel, setGenerationLevel] = useState<"B1" | "B2" | "C1">("B2");
  const [generationTheme, setGenerationTheme] = useState<string>("Sanoat Inqilobi va Ekologiya");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [genError, setGenError] = useState<string | null>(null);

  const activeSet = practiceSets.find(s => s.id === activeSetId);

  // Trigger Gemini dynamic reading passage generation
  const handleGenerateReading = async () => {
    setIsGenerating(true);
    setGenError(null);
    try {
      const response = await fetch("/api/generate-reading", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          level: generationLevel,
          theme: generationTheme
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "O'qish matnini yaratishda xato yuz berdi");
      }

      const generatedSet = await response.json();
      // Ensure it gets a unique ID
      const newSetWithId: PracticeSet = {
        ...generatedSet,
        id: `gen-set-${Date.now()}`
      };

      onAddNewPracticeSet(newSetWithId);
      setActiveSetId(newSetWithId.id);
      // Reset quiz state for the new set
      setUserAnswers({});
      setSubmitted(false);
    } catch (err: any) {
      setGenError(err.message || "Ulanishda xato yuz berdi");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (submitted) return; // Cannot change answer after submission
    setUserAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };

  const handleSubmitQuiz = () => {
    if (!activeSet) return;
    // Check if at least one answer exists
    if (Object.keys(userAnswers).length === 0) {
      alert("Iltimos, kamida bitta savolga javob belgilang.");
      return;
    }
    setSubmitted(true);
  };

  const handleResetQuiz = () => {
    setUserAnswers({});
    setSubmitted(false);
  };

  // Calculate score
  const getScore = () => {
    if (!activeSet) return 0;
    let correct = 0;
    activeSet.questions.forEach(q => {
      if (userAnswers[q.id] === q.correctOptionIndex) {
        correct++;
      }
    });
    return {
      correct,
      total: activeSet.questions.length,
      percentage: Math.round((correct / activeSet.questions.length) * 100)
    };
  };

  const scoreStats = submitted ? getScore() : null;

  return (
    <div id="practice-panel" className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-800 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            CEFR Mashqlar Zonasi
          </h2>
          <p className="text-xs text-slate-500">Tayyorgarlik darajangizni oshirish uchun testlarni yeching va tahlil qiling.</p>
        </div>

        {/* SET SELECTOR */}
        <div className="flex flex-wrap gap-2 items-center">
          <label className="text-xs font-semibold text-slate-400 uppercase">Testni tanlang:</label>
          <select
            value={activeSetId}
            onChange={(e) => {
              setActiveSetId(e.target.value);
              setUserAnswers({});
              setSubmitted(false);
            }}
            className="text-xs font-semibold border border-slate-200 rounded-lg p-2 bg-white text-slate-700 min-w-[200px] focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {practiceSets.map(set => (
              <option key={set.id} value={set.id}>
                [{set.level}] {set.title} ({set.category})
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* LEFT COLUMN: ACTIVE QUIZ */}
        <div className="lg:col-span-2 space-y-6">
          {activeSet ? (
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-6">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="bg-blue-100 text-blue-600 text-xs px-2.5 py-0.5 rounded-full font-bold uppercase">
                      CEFR {activeSet.level}
                    </span>
                    <span className="bg-slate-100 text-slate-600 text-xs px-2.5 py-0.5 rounded-full font-bold uppercase">
                      {activeSet.category}
                    </span>
                  </div>
                  <h3 id="quiz-title" className="text-lg md:text-xl font-bold text-slate-800">
                    {activeSet.title}
                  </h3>
                </div>

                {submitted && (
                  <button
                    onClick={handleResetQuiz}
                    className="flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Qayta urinish
                  </button>
                )}
              </div>

              {/* READING PASSAGE (IF PRESENT) */}
              {activeSet.passage && (
                <div className="bg-slate-50 border border-slate-100 rounded-xl p-5 text-sm leading-relaxed text-slate-600 font-medium">
                  <h4 className="font-extrabold text-slate-800 mb-3 text-xs uppercase tracking-wider text-indigo-500">O'qish matni (Passage):</h4>
                  <div className="whitespace-pre-line space-y-2 font-sans">
                    {activeSet.passage}
                  </div>
                </div>
              )}

              {/* QUESTIONS LIST */}
              <div className="space-y-8">
                {activeSet.questions.map((q, qIndex) => {
                  const answeredIndex = userAnswers[q.id];
                  return (
                    <div key={q.id} id={`question-${q.id}`} className="space-y-3">
                      <h5 className="font-bold text-slate-800 text-sm md:text-base flex gap-2">
                        <span className="text-blue-600">{qIndex + 1}.</span>
                        {q.questionText}
                      </h5>

                      <div className="grid grid-cols-1 gap-2.5">
                        {q.options.map((opt, optIndex) => {
                          const isSelected = answeredIndex === optIndex;
                          const isCorrect = q.correctOptionIndex === optIndex;

                          let bgStyle = "border-slate-100 hover:border-slate-300 bg-white";
                          let dotStyle = "border-slate-300";

                          if (isSelected) {
                            bgStyle = "ring-2 ring-blue-500 border-blue-500 bg-blue-50/40";
                            dotStyle = "border-blue-600 bg-blue-600 text-white";
                          }

                          if (submitted) {
                            if (isCorrect) {
                              // Mark correct
                              bgStyle = "border-emerald-500 ring-2 ring-emerald-500 bg-emerald-50/30";
                              dotStyle = "border-emerald-600 bg-emerald-600 text-white";
                            } else if (isSelected) {
                              // If selected but incorrect
                              bgStyle = "border-rose-500 bg-rose-50/20";
                              dotStyle = "border-rose-600 bg-rose-600 text-white animate-pulse";
                            } else {
                              bgStyle = "border-slate-200 opacity-60";
                            }
                          }

                          return (
                            <button
                              key={optIndex}
                              onClick={() => handleSelectOption(q.id, optIndex)}
                              className={`flex items-start text-left text-xs md:text-sm p-3.5 rounded-xl border transition-all ${bgStyle}`}
                              disabled={submitted}
                            >
                              <div className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center text-[10px] font-black mr-3 flex-shrink-0 ${dotStyle}`}>
                                {optIndex === 0 ? "A" : optIndex === 1 ? "B" : optIndex === 2 ? "C" : "D"}
                              </div>
                              <span className="text-slate-700 font-medium">{opt}</span>
                            </button>
                          );
                        })}
                      </div>

                      {/* FEEDBACK EXPLANATION IF SUBMITTED */}
                      {submitted && (
                        <div className="bg-amber-50/50 border border-amber-200/60 rounded-xl p-4 text-xs text-amber-900 mt-2 space-y-1">
                          <span className="font-bold flex items-center gap-1.5 text-amber-800">
                            <HelpCircle className="w-4 h-4 text-amber-600" />
                            O'zbek tilida tushuntirish:
                          </span>
                          <p className="font-medium text-slate-700 leading-relaxed">{q.explanation}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* ACTION BUTTON */}
              {!submitted && (
                <div className="pt-4 border-t border-slate-100 flex justify-end">
                  <button
                    onClick={handleSubmitQuiz}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-6 rounded-xl text-sm transition-all shadow-md flex items-center gap-2"
                  >
                    Natijalarni tekshirish <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          ) : (
            <p className="text-slate-500">Hech qanday dars mashg'uloti topilmadi.</p>
          )}
        </div>

        {/* RIGHT COLUMN: AI GENERATOR & SCORECARD */}
        <div className="space-y-6">
          {/* LIVE SCOREBOARD SUBMITTED */}
          {submitted && scoreStats && (
            <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-xl p-6 shadow-md border border-emerald-500 space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="bg-white/20 p-2 rounded-lg">
                  <Award className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-bold">Sizning Natijangiz!</h4>
                  <p className="text-[10px] text-emerald-100 uppercase tracking-widest font-mono">Xatolar va progress tahlili</p>
                </div>
              </div>

              <div className="text-center py-4 bg-white/10 rounded-xl border border-white/10">
                <span className="block text-4xl font-extrabold">{scoreStats.correct} / {scoreStats.total}</span>
                <span className="text-xs text-emerald-100 font-semibold">{scoreStats.percentage}% To'g'ri javob</span>
              </div>

              <p className="text-xs text-emerald-100 leading-relaxed font-medium">
                Sizning natijangiz tahlil qilindi. O'zingiz qoldirgan xatolarni va ularning batafsil izohini savollar ostidagi tahlil bo'limidan o'rganishingiz mumkin!
              </p>
            </div>
          )}

          {/* AI GENERATOR CARD */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <div className="bg-blue-50 p-2 rounded-lg">
                <Sparkles className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">Sun'iy Intellekt yordamida yangi matn va testlar</h4>
                <p className="text-[10px] text-slate-400">Gemini modeliga yangi o'quv materiallari generatsiya qildiring.</p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">CEFR Daraja</label>
                <div className="flex gap-2">
                  {(["B1", "B2", "C1"] as const).map(lev => (
                    <button
                      key={lev}
                      type="button"
                      onClick={() => setGenerationLevel(lev)}
                      className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-colors border ${
                        generationLevel === lev
                          ? "bg-blue-600 text-white border-blue-600"
                          : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      {lev}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Mavzu / Yo'nalish</label>
                <input
                  type="text"
                  value={generationTheme}
                  onChange={(e) => setGenerationTheme(e.target.value)}
                  placeholder="Masalan: Uzbek traditions, ecology"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 text-slate-700"
                />
              </div>

              {genError && (
                <div className="bg-rose-50 text-rose-600 text-xs p-3 rounded-lg border border-rose-100 font-medium">
                  {genError}
                </div>
              )}

              <button
                type="button"
                onClick={handleGenerateReading}
                disabled={isGenerating}
                className="w-full py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold transition-all hover:bg-slate-800 flex items-center justify-center gap-2 cursor-pointer shadow-sm disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    Generator ishlamoqda...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-blue-400" />
                    Matn va savollar yaratish
                  </>
                )}
              </button>
            </div>

            {!geminiConfigured && (
              <p className="text-[10px] text-rose-500 italic mt-2 font-semibold">
                * Eslatma: Generatsiya funksiyasidan foydalanish uchun Secrets paneliga GEMINI_API_KEY bog'langan bo'lishi kerak.
              </p>
            )}
            {geminiConfigured && (
              <p className="text-[10px] text-emerald-600 italic mt-2 font-semibold">
                ✓ Gemini ulangan. Istalgan vaqtda yangi testlarni yaratishingiz mumkin.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
