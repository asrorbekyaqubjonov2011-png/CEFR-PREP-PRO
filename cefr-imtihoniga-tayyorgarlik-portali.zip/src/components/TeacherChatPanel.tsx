/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { MessageSquare, Send, RefreshCw, Compass, AlertCircle, HelpCircle } from "lucide-react";

interface Message {
  id: string;
  sender: "user" | "teacher";
  text: string;
}

const FAQ_PROMPTS = [
  {
    qs: "CEFR multi-level imtihoni o'zi nima va baholash qanday bo'ladi?",
    label: "CEFR haqida umumiy tushuncha"
  },
  {
    qs: "Inversion (Inverted sentences) grammatik qoidasini batafsil va murakkab misollar bilan tushuntirib bering.",
    label: "Inversion qoidasi tahlili"
  },
  {
    qs: "21-avgust kuni imtihonim bor, shu vaqtgacha qanday reja asosida tezroq B2/C1 darajaga chiqsam bo'ladi?",
    label: "Avgustgacha o'quv rejasi"
  },
  {
    qs: "Writing Task 2 da yuqori ball (C1) olish uchun foydalanish kerak bo'lgan linking word va academic lug'atlar qaysilar?",
    label: "C1 Writing iboralari"
  }
];

interface TeacherChatPanelProps {
  geminiConfigured: boolean;
}

export default function TeacherChatPanel({
  geminiConfigured
}: TeacherChatPanelProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "wel-1",
      sender: "teacher",
      text: "Assalomu alaykum! Men sizning CEFR tayyorgarlik bo'yicha shaxsiy repetitoringizman. 21-avgust kuni bo'ladigan CEFR imtihoningizga mukammal tayyorlanishingiz uchun har qanday savolingizga (grammatika, writing tahlillari, o'qish usullari yoki rejalashtirish) o'zbek va ingliz tilida javob bera olaman. Savolingizni yozing yoki quyidagi takliflardan birini bosing:"
    }
  ]);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    // Add user message
    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: "user",
      text: textToSend
    };
    setMessages(prev => [...prev, userMsg]);
    setUserInput("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/ask-helper", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: textToSend })
      });

      if (!response.ok) {
        throw new Error("Tizim javob bermadi. Iltimos kalitingizni tekshiring.");
      }

      const result = await response.json();
      const teacherMsg: Message = {
        id: `tch-${Date.now()}`,
        sender: "teacher",
        text: result.text || "Kechirasiz, javob olishda xatolik yuz berdi."
      };
      setMessages(prev => [...prev, teacherMsg]);
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: "teacher",
          text: `Sun'iy intellekt xizmati ulanmadi. Error: ${err.message}. Iltimos, o'ng tarafdagi Secrets bo'limida GEMINI_API_KEY to'g'ri o'rnatilganligini tasdiqlang.`
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div id="teacher-chat-panel" className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="bg-blue-50 p-2.5 rounded-xl border border-blue-100">
          <MessageSquare className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-800">CEFR Repetitor AI-Maslahatchi</h2>
          <p className="text-xs text-slate-500">Grammatika va imtihondagi qiyin savollar haqida repetitordan so'rang.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* CHAT MESSAGES WINDOW */}
        <div className="lg:col-span-3 bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4 flex flex-col h-[520px]">
          {/* CHAT BOX CONTAINER */}
          <div className="flex-1 overflow-y-auto space-y-4 pr-1 select-text">
            {messages.map((msg) => {
              const isUser = msg.sender === "user";
              return (
                <div
                  key={msg.id}
                  className={`flex ${isUser ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-4 text-xs md:text-sm font-medium leading-relaxed shadow-sm border ${
                      isUser
                        ? "bg-slate-900 border-slate-950 text-white rounded-br-none"
                        : "bg-slate-50 border-slate-150 text-slate-700 rounded-bl-none"
                    }`}
                  >
                    {!isUser && (
                      <span className="block text-[10px] uppercase tracking-wider font-extrabold text-blue-600 mb-1">
                        CEFR AI Coach
                      </span>
                    )}
                    <span className="whitespace-pre-line font-medium leading-relaxed font-sans">{msg.text}</span>
                  </div>
                </div>
              );
            })}

            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-slate-50 border border-slate-100 rounded-2xl rounded-bl-none p-4 text-slate-500 text-xs shadow-sm flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin text-blue-600" />
                  <span>Repetitor o'ylab javob yozmoqda...</span>
                </div>
              </div>
            )}
          </div>

          {/* INPUT AND SEND FORM */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(userInput);
            }}
            className="border-t border-slate-100 pt-3 flex gap-2"
          >
            <input
              type="text"
              disabled={isLoading}
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Grammatika qoidasi, insho yozish turlari haqida so'rang..."
              className="flex-1 text-xs md:text-sm px-4 py-2.5 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 placeholder-slate-400 text-slate-800 font-medium"
            />
            <button
              type="submit"
              disabled={isLoading || !userInput.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-xl transition-all shadow-sm flex items-center justify-center disabled:opacity-50 cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* REPETITOR FAQ / QUICK ACTIONS */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider text-blue-600 flex items-center gap-1">
              <Compass className="w-4 h-4" />
              Tezkor so'rovlar
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed font-medium">
              Quyidagi eng dolzarb va muhim CEFR savollaridan birini tanlab bosish orqali repetitor javobini oling:
            </p>

            <div className="space-y-2.5">
              {FAQ_PROMPTS.map((item, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => handleSendMessage(item.qs)}
                  disabled={isLoading}
                  className="w-full text-left p-3 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors text-xs font-semibold text-slate-700 block disabled:opacity-50"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {!geminiConfigured && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-2 text-xs font-medium text-amber-900 shadow-sm leading-relaxed">
              <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Diqqat:</span> Gemini repetitor xizmatidan foydalanish uchun Secrets paneliga GEMINI_API_KEY qiymatini o'rnating.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
