/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Initialize Gemini SDK lazily to avoid startup crashes if key is omitted.
let aiInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY || "";
    if (!apiKey) {
      console.warn("WARNING: GEMINI_API_KEY is missing from environment variables.");
    }
    aiInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

// Ensure error response helper
const handleApiError = (res: express.Response, err: any) => {
  console.error("API error:", err);
  res.status(500).json({
    error: err.message || "Xatolik yuz berdi",
    details: err.stack || "",
  });
};

// --- API Endpoints ---

// 1. Health & Configuration check
app.get("/api/config", (req, res) => {
  res.json({
    geminiConfigured: !!process.env.GEMINI_API_KEY,
  });
});

// 2. Generate a CEFR level Practice Reading Passage & Questions
app.post("/api/generate-reading", async (req, res) => {
  try {
    const { level, theme } = req.body;
    const client = getGeminiClient();

    if (!process.env.GEMINI_API_KEY) {
      return res.status(400).json({
        error: "GEMINI_API_KEY topilmadi. Iltimos, AI Studio Settings > Secrets bo'limida kalitni kiriting.",
      });
    }

    const prompt = `Siz professional DTM va milliy CEFR (Multi-level) imtihonlari tuzuvchi eksperti ekansiz.
Menga bitta CEFR ${level || "B2"} darajasidagi yangi "Reading" matnini (passage) va unga bog'liq 5 ta test savolini yaratib bering.
Mavzu bo'lishi kerak: "${theme || "Education & Technology"}".
Hamma savollarda 4 ta variant (A, B, C, D) bo'lsin.
Javob variantlari orasida faqat bitta to'g'ri bo'lsin.
Har bir savol uchun tushunarli o'zbek tilida tushuntirish ("explanation") yozilsin.

Natijani quyidagi JSON sxema bo'yicha qaytaring:
{
  "title": "Mavzu sarlavhasi (Ingliz tilida)",
  "level": "${level || "B2"}",
  "category": "Reading",
  "passage": "Ingliz tilidagi 250-400 so'zli o'qish matni (paragraf bo'lingan holda)",
  "questions": [
    {
      "id": "q1",
      "questionText": "Savol matni (ingliz tilida)",
      "options": ["A variant", "B variant", "C variant", "D variant"],
      "correctOptionIndex": 0,  // To'g'ri variantning indeksi (0 dan 3 gacha)
      "explanation": "Ushbu javobning to'g'riligi haqida o'zbek tilidagi qisqacha tahlil"
    }
  ]
}`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            level: { type: Type.STRING },
            category: { type: Type.STRING },
            passage: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  questionText: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  correctOptionIndex: { type: Type.INTEGER },
                  explanation: { type: Type.STRING },
                },
                required: ["id", "questionText", "options", "correctOptionIndex", "explanation"],
              },
            },
          },
          required: ["title", "level", "category", "passage", "questions"],
        },
      },
    });

    const body = response.text ? response.text.trim() : "{}";
    res.json(JSON.parse(body));
  } catch (err: any) {
    handleApiError(res, err);
  }
});

// 3. Evaluate Writing Draft based on Uzbek Multi-level CEFR
app.post("/api/evaluate-writing", async (req, res) => {
  try {
    const { taskNumber, prompt: taskPrompt, studentAnswer } = req.body;
    const client = getGeminiClient();

    if (!process.env.GEMINI_API_KEY) {
      return res.status(400).json({
        error: "GEMINI_API_KEY topilmadi. Iltimos, AI Studio Settings > Secrets bo'limida kalitni kiriting.",
      });
    }

    if (!studentAnswer || studentAnswer.length < 10) {
      return res.status(400).json({
        error: "Tekshirish uchun insho yetarli uzunlikda emas. Kamida 10 ta belgi kiriting.",
      });
    }

    const prompt = `Siz milliy CEFR (Multi-Level) va IELTS imtihoni baholovchisi ekansiz (Uzbekistan DTM standartlari bo'yicha).
Quyidagi Writing Task ${taskNumber || 1} imtihon topshirig'ini va talabaning javobini baholang:

--- TOPSHIRIQ PROMPT ---
${taskPrompt}

--- TALABANING JAVOBI ---
${studentAnswer}

Iltimos, ushbu bandlar bo'yicha baholang:
1. Umumiylashtirilgan CEFR darajasi (B1, B2 yoki C1) va taxminiy IELTS ekvivalenti (masalan: "B2 (IELTS 6.0)" kabi).
2. Coherence & Cohesion (Bog'liqlik) tahlili va o'zbek tilidagi tavsiya.
3. Lexical Resource (Lug'at boyligi) tahlili, kamchiliklar va rivojlantirish bo'yicha o'zbek tilidagi tavsiya.
4. Grammatical Range & Accuracy (Grammatika va aniqlik) tahlili hamda xatolarni ko'rsatuvchi o'zbek tilidagi tavsiya.
5. Task Achievement / Response (Vazifani bajarganlik) tahlili.
6. "Improved Version" - Talabaning javobini grammatik, leksik va stilistik jihatdan mukammal qilib qayta yozilgan nusxasi (hech bo'lmaganda B2/C1 darajaga moslab yuboring, lekin talabaning asl g'oyasini saqlab qoling).

Natijani quyidagi JSON formatida aniq qaytaring:
{
  "score": "CEFR va taxminiy IELTS darajasi (masalan, B2 - 6.0)",
  "coherenceText": "Coherence va Cohesion bog'liqligi bo'yicha tahlil (o'zbek tilida)",
  "lexicalText": "Leksik (lug'at) bo'yicha tahlil va tavsiyalar (o'zbek tilida)",
  "grammaticalText": "Grammatika bo'yicha tahlil va xatolar tuzatishi (o'zbek tilida)",
  "taskAchievementText": "Vazifaga to'laqonli javob berilganligi bo'yicha tahlil (o'zbek tilida)",
  "improvedVersion": "Ingliz tilidagi qaytadan professional darajada yaxshilangan insho varianti"
}`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.STRING },
            coherenceText: { type: Type.STRING },
            lexicalText: { type: Type.STRING },
            grammaticalText: { type: Type.STRING },
            taskAchievementText: { type: Type.STRING },
            improvedVersion: { type: Type.STRING },
          },
          required: [
            "score",
            "coherenceText",
            "lexicalText",
            "grammaticalText",
            "taskAchievementText",
            "improvedVersion",
          ],
        },
      },
    });

    const body = response.text ? response.text.trim() : "{}";
    res.json(JSON.parse(body));
  } catch (err: any) {
    handleApiError(res, err);
  }
});

// 4. Generate Grammar/Vocabulary Multi-level Explanation or AI chat helper
app.post("/api/ask-helper", async (req, res) => {
  try {
    const { question } = req.body;
    const client = getGeminiClient();

    if (!process.env.GEMINI_API_KEY) {
      return res.status(400).json({
        error: "GEMINI_API_KEY topilmadi.",
      });
    }

    const systemPrompt = `Siz milliy CEFR dars beradigan tajribali repetitorsiz. Savollarga doimo o'zbek tilida ravon, tushunarli, dalillar bilan, misollar keltirgan holda javob berasiz. Talabaga 21-avgust kuni bo'ladigan CEFR imtihonini muvaffaqiyatli topshirishga yordam bering.`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: question,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    res.json({ text: response.text });
  } catch (err: any) {
    handleApiError(res, err);
  }
});

// --- Server-side Vite Setup ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CEFR Prep Server is running on http://localhost:${PORT}`);
  });
}

startServer();
